verificar en otros repos los metodos/interfaces
donde pongo las rutas de cada uno? 7